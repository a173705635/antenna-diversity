"""Single-antenna assisted GPS L1/L5 Q5 RF-to-position comparison.

Two frequency streams share physical trajectories and a clock, not RF noise.
No ionosphere, inter-frequency bias, CNAV decoding or integer ambiguity fixing.
"""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import numpy as np

from config import SPEED_OF_LIGHT_MPS
from positioning import carrier_range, solve_position, solve_code_carrier_float
from run_gps_spp import build_scene, satellite_setup, run_record, receiver_reference, serializable


def position_stats(positions):
    error = np.asarray(positions)-receiver_reference()[0]
    valid = np.isfinite(error).all(axis=1)
    result = {'epochs': len(error), 'solved_epochs': int(valid.sum())}
    if valid.any():
        e = error[valid]
        result.update(position_rms_m=float(np.sqrt(np.mean(np.sum(e*e, axis=1)))),
                      demeaned_rms_m=float(np.sqrt(np.mean(np.sum((e-e.mean(axis=0))**2, axis=1)))))
    return result


def compare(records, satellites, weights=None):
    times = np.asarray(records['L1CA']['time_s'])
    if not np.array_equal(times, records['L5Q']['time_s']):
        raise ValueError('frequency streams must share observation times')
    states = np.array([[s['position_m']+s['velocity_mps']*t for s in satellites] for t in times])
    phases = {}
    codes = {}
    for kind, frequency in [('L1CA', 1575.42e6), ('L5Q', 1176.45e6)]:
        record = records[kind]
        codes[kind] = np.asarray(record['pseudoranges_m'], dtype=float)
        phases[kind] = np.full_like(codes[kind], np.nan)
        for column, history in enumerate(record['satellite_tracking']):
            if history.get('tracking_status') == 'tracking':
                phases[kind][:, column] = carrier_range(dict(history, success=True), times,
                    record['fs_dfe_hz'], .001, SPEED_OF_LIGHT_MPS/frequency)
        phases[kind][~np.isfinite(codes[kind])] = np.nan
    output = {}
    modes = [('L1', ['L1CA']), ('L5', ['L5Q']), ('L1_L5', ['L1CA', 'L5Q'])]
    if weights is not None:
        modes += [('L5_weighted', ['L5Q']), ('dual_weighted', ['L1CA', 'L5Q']),
                  ('L5_code_dual_phase', ['L1CA', 'L5Q'])]
    for name, kinds in modes:
        p = np.concatenate([codes[k] for k in kinds], axis=1)
        l = np.concatenate([phases[k] for k in kinds], axis=1)
        geometry = np.concatenate([states for k in kinds], axis=1)
        cs, ls = np.full(p.shape[1], 30.), np.full(p.shape[1], .01)
        if name in ('L5_weighted', 'dual_weighted', 'L5_code_dual_phase'):
            cs = np.concatenate([np.full(len(satellites), weights[k]['code_sigma_m']) for k in kinds])
            ls = np.concatenate([np.full(len(satellites), weights[k]['carrier_sigma_m']) for k in kinds])
        if name == 'L5_code_dual_phase':
            cs[:len(satellites)] = np.inf
        positions = np.full((len(times), 3), np.nan)
        for i in range(len(times)):
            valid = np.isfinite(p[i])
            try:
                positions[i] = solve_position(geometry[i, valid], p[i, valid], sigma_m=cs[valid])['position_m']
            except ValueError:
                pass
        result = {'code': position_stats(positions), 'code_position_ecef_m': positions,
                  'observation_labels': [f'{k}:PRN{s["prn"]}' for k in kinds for s in satellites]}
        # Offline float ambiguities are independent per satellite AND frequency.
        # Do not bridge missing epochs or silently supply truth for rejected data.
        if np.isfinite(p).all() and np.isfinite(l).all():
            try:
                solution = solve_code_carrier_float(geometry, p, l, code_sigma_m=cs, carrier_sigma_m=ls)
                result['float'] = position_stats(solution['position_m'])
                result['float_solution'] = solution
                result['carrier_postfit_max_m'] = float(abs(solution['carrier_residual_m']).max())
                result['phase_residual_screen_passed'] = result['carrier_postfit_max_m'] <= .05
            except ValueError as exc:
                result['float_failure'] = str(exc)
        else:
            result['float_failure'] = 'incomplete continuous common arc'
        output[name] = result
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--duration-ms', type=int, default=1000)
    parser.add_argument('--seeds', type=int, nargs='+', default=[4000, 4001, 4002])
    parser.add_argument('--weights', type=Path, default=Path(__file__).with_name('dual_frequency_weights.json'))
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent/'results/gps_l1_l5')
    args = parser.parse_args()
    if args.duration_ms < 300 or any(s < 0 for s in args.seeds) or len(set(args.seeds)) != len(args.seeds):
        parser.error('duration >=300 ms and distinct nonnegative seeds required')
    args.output.mkdir(parents=True, exist_ok=False)
    weights = json.loads(args.weights.read_text(encoding='utf-8'))
    def save(name, data):
        (args.output/name).write_text(json.dumps(serializable(data), indent=2, allow_nan=False), encoding='utf-8')
    satellites = satellite_setup()
    manifest = {'scope': __doc__, 'satellites': satellites, 'duration_ms': args.duration_ms,
                'seeds': args.seeds, 'frequency_noise_seeds': 'L1=seed; L5=seed+100000',
                'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in Path(__file__).resolve().parent.glob('*.py')},
                'time_aid': 'per-satellite range rounded to 10 km; selects primary 1 ms ambiguity',
                'power': 'same configured power per tracked component; Q5 only, no I5 component',
                'float': 'offline independent real bias per satellite/frequency; no integer fixing',
                'combination': 'equal-weight baseline plus frozen band weights and L5-code/dual-phase mode; common clock',
                'recommended_mode': 'L5_code_dual_phase',
                'weight_calibration': 'seeds 4000..4002, observation scatter only; this receiver configuration',
                'weights': weights,
                'weights_sha256': hashlib.sha256(args.weights.read_bytes()).hexdigest(),
                'phase_screen': '50 mm maximum postfit residual, not certified cycle-slip protection',
                'noise_model': 'IID discrete RF samples; band-specific configured noise bandwidth',
                'frequency_configs': {}}
    records = {seed: {} for seed in args.seeds}
    for kind in ['L1CA', 'L5Q']:
        print(f'Generating {kind} scene...', flush=True)
        scene, cfg = build_scene(satellites, args.duration_ms, signal_kind=kind)
        manifest['frequency_configs'][kind] = {'signal': asdict(cfg.signal), 'rf': asdict(cfg.rf),
                                             'dfe': asdict(cfg.dfe), 'tracking': asdict(cfg.tracking)}
        save('manifest.json', manifest)
        for seed in args.seeds:
            record = run_record(seed+(100000 if kind == 'L5Q' else 0), satellites, scene, cfg)
            records[seed][kind] = record
            save(f'{kind}_{seed}.json', record)
        del scene
    summaries = []
    for seed in args.seeds:
        result = compare(records[seed], satellites, weights)
        save(f'comparison_{seed}.json', result)
        summary = {'seed': seed, 'modes': {name: {key: value for key, value in mode.items()
                    if key in ('code', 'float', 'float_failure', 'carrier_postfit_max_m', 'phase_residual_screen_passed')}
                   for name, mode in result.items()}}
        summaries.append(summary)
        print(json.dumps(summary), flush=True)
    save('summary.json', summaries)
    save('sha256.json', {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in args.output.glob('*.json') if p.name != 'sha256.json'})


if __name__ == '__main__':
    main()
