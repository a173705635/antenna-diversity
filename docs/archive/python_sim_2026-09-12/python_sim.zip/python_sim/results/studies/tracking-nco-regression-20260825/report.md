# 空间抗干扰研究报告

## 概览

本报告是基于已保存规范化结果的**比较性研究**，用于比较模型内不同组合与算法；不代表真实 Mate 70 产品性能。
研究状态：`completed`；Git SHA：`c75fc149c2b7adce6c17662b18c127ffcd31823b`；配置哈希：`04b53febb426595b1dce0e3cd230d0d76f5c42282265603f821805b408be65f6`。

## 基线排名

最佳组合：`TL+TR+BR`；全方向 p10/中位数/最小值：`-23.215840335747696`/`-21.00373348124269`/`-24.266888528961367` dB；可分辨区域 p10/中位数/最小值：`-21.70136830046298`/`-21.00123442512897`/`-22.164792142534026` dB。 典型组合：`TL+TR+BR`；全方向 p10/中位数/最小值：`-23.215840335747696`/`-21.00373348124269`/`-24.266888528961367` dB；可分辨区域 p10/中位数/最小值：`-21.70136830046298`/`-21.00123442512897`/`-22.164792142534026` dB。 最差组合：`TL+BR`；全方向 p10/中位数/最小值：`-27.70198590987085`/`-23.987860048130614`/`-29.19114569284777` dB；可分辨区域 p10/中位数/最小值：`-27.519131093378473`/`-22.964610902086704`/`-29.19114569284777` dB。
[基线图](figures/baseline_rankings.png)

## 空间全景

[方向热力图](figures/direction_heatmaps.png)

## 功率

[功率曲线](figures/power_curves.png)

## 鲁棒性

性能拐点不可用：not selected
[鲁棒性曲线](figures/robustness_curves.png)

## 组合误差

synthetic_mismatch：中位数 -23.097217033583313 dB。
[组合误差分布](figures/combined_error_distributions.png)

## 多干扰压力

two_linear_jammers/TL+BR/egc：输出 SINR -28.077304636104422 dB，最差干扰增益 0.24611414439133195。 two_linear_jammers/TL+BR/mvdr：输出 SINR -25.4456461261574 dB，最差干扰增益 0.1391171542718741。 two_linear_jammers/TL+TR+BR/egc：输出 SINR -24.725031761584244 dB，最差干扰增益 0.14790712052737917。 two_linear_jammers/TL+TR+BR/mvdr：输出 SINR -21.987231967193473 dB，最差干扰增益 0.060372550043825406。
[多干扰比较](figures/multi_jammer_comparison.png)

## 手机天线模型证据

模型来源：`parametric`；标签：`synthetic_phone_corner_v1`；诊断阵元：`TL+TR+BL+BR`。以下图均由基线阶段保存的标量诊断行生成，不在报告阶段重算模型。
[单阵元方向图](figures/element_patterns.png)
[极化匹配增益](figures/polarization_losses.png)
[互耦幅相矩阵](figures/coupling_matrices.png)
[遮挡衰减对比](figures/blockage_comparison.png)

## RF 到跟踪验证

完整链路字段保留 `analytic_output_sinr_db` 与 `final_cn0_db_hz`；捕获或跟踪失败是有效结果，并以不可用原因呈现。
EGC：捕获率 0.0，跟踪率 0.0；MVDR：捕获率 1.0，跟踪率 1.0；SINGLE：捕获率 1.0，跟踪率 1.0。
[完整链路验证](figures/full_chain_validation.png)
[C/N₀ 验证](figures/cn0_validation.png)

## 结论与限制

仿真框架可表示四角子阵、窄带复数双极化阵元响应、安装姿态、可配置遮挡与互耦、真实/假设模型失配、静态 CW 干扰、SINGLE/EGC/MVDR、解析空间指标和 RF/ADC/DFE/捕获/跟踪/C/N₀ 链路。本次工件实际启用的天线来源由上节明确标记；参数化模型不代表真实 Mate 70 产品测量。

### 未建模

- 多径、NLOS、运动与动态到达方向，以及非 CW、宽带、扫频、脉冲或调制干扰。
- 多颗卫星、多 PRN、导航电文、定位解算与 PVT，以及实时权值更新和硬件实现限制。
- 互耦导致的相关外部天线噪声，以及机壳/人体的全波平台散射和产品级电磁验证。

## 复现

以下链接指向本研究目录中的固定工件：
[antenna_diagnostics](tables/antenna_diagnostics.csv)
[baseline_rankings](tables/baseline_rankings.csv)
[combined_errors](tables/combined_errors.csv)
[direction_scan](tables/direction_scan.csv)
[full_chain_cn0](tables/full_chain_cn0.csv)
[full_chain_validation](tables/full_chain_validation.csv)
[multi_jammer](tables/multi_jammer.csv)
[power_scan](tables/power_scan.csv)
[robustness_scans](tables/robustness_scans.csv)
[blockage_comparison](figures/blockage_comparison.png)
[cn0_validation](figures/cn0_validation.png)
[combined_error_distributions](figures/combined_error_distributions.png)
[coupling_matrices](figures/coupling_matrices.png)
[direction_heatmaps](figures/direction_heatmaps.png)
[element_patterns](figures/element_patterns.png)
[full_chain_validation](figures/full_chain_validation.png)
[multi_jammer_comparison](figures/multi_jammer_comparison.png)
[polarization_losses](figures/polarization_losses.png)
[power_curves](figures/power_curves.png)
[robustness_curves](figures/robustness_curves.png)
